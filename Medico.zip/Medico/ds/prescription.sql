-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.30 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for prescription
CREATE DATABASE IF NOT EXISTS `prescription` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `prescription`;

-- Dumping structure for table prescription.admin_master
CREATE TABLE IF NOT EXISTS `admin_master` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `unique_id` varchar(25) NOT NULL,
  `image` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table prescription.admin_master: ~0 rows (approximately)
INSERT INTO `admin_master` (`id`, `first_name`, `last_name`, `email`, `contact`, `unique_id`, `image`, `status`, `created_date`) VALUES
	(1, 'Admind', 'Userd', 'admin@gmail.comd', '8956856986', 'UIDA56223', 'user/user_image.jpg', 1, '2021-07-14 13:18:30');

-- Dumping structure for table prescription.city_master
CREATE TABLE IF NOT EXISTS `city_master` (
  `City_id` int NOT NULL AUTO_INCREMENT,
  `State_id` int NOT NULL,
  `District_id` int NOT NULL,
  `City_name` varchar(50) NOT NULL,
  `City_status` tinyint(1) NOT NULL,
  `City_created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`City_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table prescription.city_master: 2 rows
/*!40000 ALTER TABLE `city_master` DISABLE KEYS */;
INSERT INTO `city_master` (`City_id`, `State_id`, `District_id`, `City_name`, `City_status`, `City_created_date`) VALUES
	(1, 1, 1, 'sdf', 1, '2021-07-14 14:13:21'),
	(2, 1, 1, 'rd', 1, '2021-07-15 11:29:17');
/*!40000 ALTER TABLE `city_master` ENABLE KEYS */;

-- Dumping structure for table prescription.company_master
CREATE TABLE IF NOT EXISTS `company_master` (
  `Company_id` int NOT NULL AUTO_INCREMENT,
  `Company_name` varchar(25) NOT NULL,
  `Company_Address` text NOT NULL,
  `Company_Contact` varchar(15) NOT NULL,
  `Company_Status` tinyint(1) NOT NULL,
  `Created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Company_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table prescription.company_master: 1 rows
/*!40000 ALTER TABLE `company_master` DISABLE KEYS */;
INSERT INTO `company_master` (`Company_id`, `Company_name`, `Company_Address`, `Company_Contact`, `Company_Status`, `Created_date`) VALUES
	(1, 'fgs', 'dsfgs', '8904652353', 1, '2021-07-14 14:09:05');
/*!40000 ALTER TABLE `company_master` ENABLE KEYS */;

-- Dumping structure for table prescription.complaint_master
CREATE TABLE IF NOT EXISTS `complaint_master` (
  `complaint_id` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(25) NOT NULL,
  `complaint_title` varchar(100) NOT NULL,
  `complaint_description` text NOT NULL,
  `complaint_status` tinyint(1) NOT NULL,
  `posted_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`complaint_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table prescription.complaint_master: 2 rows
/*!40000 ALTER TABLE `complaint_master` DISABLE KEYS */;
INSERT INTO `complaint_master` (`complaint_id`, `user_id`, `complaint_title`, `complaint_description`, `complaint_status`, `posted_on`) VALUES
	(1, 'UID322676', 'dgfsdg', 'gds', 1, '2021-07-14 14:23:20'),
	(2, 'UID322676', 'fdg', 'dfg', 1, '2021-07-14 14:45:19');
/*!40000 ALTER TABLE `complaint_master` ENABLE KEYS */;

-- Dumping structure for table prescription.district_master
CREATE TABLE IF NOT EXISTS `district_master` (
  `District_id` int NOT NULL AUTO_INCREMENT,
  `State_id` int NOT NULL,
  `District_name` varchar(50) NOT NULL,
  `D_status` tinyint(1) NOT NULL,
  `DCreated_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`District_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table prescription.district_master: 1 rows
/*!40000 ALTER TABLE `district_master` DISABLE KEYS */;
INSERT INTO `district_master` (`District_id`, `State_id`, `District_name`, `D_status`, `DCreated_date`) VALUES
	(1, 1, 'sdgsd', 1, '2021-07-14 14:13:05');
/*!40000 ALTER TABLE `district_master` ENABLE KEYS */;

-- Dumping structure for table prescription.doctor_master
CREATE TABLE IF NOT EXISTS `doctor_master` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `specialization` varchar(25) NOT NULL,
  `email` varchar(45) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `unique_id` varchar(25) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `image` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table prescription.doctor_master: ~4 rows (approximately)
INSERT INTO `doctor_master` (`id`, `first_name`, `last_name`, `specialization`, `email`, `contact`, `unique_id`, `status`, `created_date`, `image`) VALUES
	(2, 'yer', 'ery', 'ere', 'suraj@gmail.comd', '8904652353', 'UID309669', 1, '2021-07-14 13:55:43', 'user/doctor_image.jpg'),
	(3, 'dsfgsd', 'gsdg', 'sdg', 'suraj@gmail.comd', '8904652353', 'UID720472', 1, '2021-07-14 14:47:33', 'user/doctor_image.jpg'),
	(4, 'rgretggg', 'ertw', 'twe', 'suraj@gmail.comd', '8904652353', 'UID875168', 1, '2021-07-14 14:48:39', 'user/doctor_image.jpg'),
	(5, 'vvvc', 'vvvc', 'vvv', 'admin@gmail.comdc', '6666666665', 'UID189070', 1, '2021-07-14 14:50:30', 'user/doctor_image.jpg');

-- Dumping structure for table prescription.login_master
CREATE TABLE IF NOT EXISTS `login_master` (
  `id` int NOT NULL AUTO_INCREMENT,
  `unique_id` varchar(25) NOT NULL,
  `user_type` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table prescription.login_master: ~13 rows (approximately)
INSERT INTO `login_master` (`id`, `unique_id`, `user_type`, `password`, `status`, `created_date`) VALUES
	(1, 'UID322676', 'User', 'MAnoj143', 1, '2021-07-14 12:50:44'),
	(2, 'UID956223', 'User', 'MAnoj143', 1, '2021-07-14 12:51:59'),
	(3, 'UIDA56223', 'Admin', 'MAnoj1433', 1, '2021-07-14 12:51:59'),
	(4, 'UID362376', 'Medical', 'PAss505326', 1, '2021-07-14 13:35:34'),
	(5, 'UID359731', 'Medical', 'PAss815351', 1, '2021-07-14 13:37:31'),
	(6, 'UID611939', 'Medical', 'PAss765524', 1, '2021-07-14 13:41:41'),
	(7, 'UID181760', 'Medical', 'PAss323551', 1, '2021-07-14 13:42:46'),
	(8, 'UID800087', 'Medical', 'PAss813844', 1, '2021-07-14 13:48:03'),
	(9, 'UID950936', 'Medical', 'PAss662938', 1, '2021-07-14 13:54:02'),
	(10, 'UID309669', 'Doctor', 'PAss272975', 1, '2021-07-14 13:55:43'),
	(11, 'UID720472', 'Doctor', 'PAss981175', 1, '2021-07-14 14:47:33'),
	(12, 'UID875168', 'Doctor', 'PAss458064', 1, '2021-07-14 14:48:39'),
	(13, 'UID189070', 'Doctor', 'PAss935255', 1, '2021-07-14 14:50:30');

-- Dumping structure for table prescription.medical_master
CREATE TABLE IF NOT EXISTS `medical_master` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `unique_id` varchar(25) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `address` text NOT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `image` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table prescription.medical_master: ~0 rows (approximately)
INSERT INTO `medical_master` (`id`, `first_name`, `last_name`, `email`, `contact`, `unique_id`, `status`, `address`, `created_date`, `image`) VALUES
	(5, 'erw', 'ewt', 'suraj@gmail.comd', '9787878787', 'UID800087', 1, 'rds', '2021-07-14 13:48:03', 'user/medical_image.jpg');

-- Dumping structure for table prescription.medicine
CREATE TABLE IF NOT EXISTS `medicine` (
  `id` int NOT NULL AUTO_INCREMENT,
  `medicine_id` int NOT NULL,
  `no_of_days` int NOT NULL,
  `timings` text NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL,
  `track_no` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table prescription.medicine: ~11 rows (approximately)
INSERT INTO `medicine` (`id`, `medicine_id`, `no_of_days`, `timings`, `date`, `status`, `track_no`) VALUES
	(1, 0, 1, '', '2021-07-14 15:42:58', 1, ''),
	(2, 1, 1, 'Morning, ', '2021-07-14 16:04:06', 1, '889500'),
	(3, 1, 1, 'Morning, Afternoon, ', '2021-07-14 16:04:29', 1, '889500'),
	(4, 1, 1, 'Morning, Afternoon, ', '2021-07-14 16:05:22', 1, '889500'),
	(5, 1, 1, 'Morning, Afternoon, Night, ', '2021-07-14 16:07:39', 1, '889500'),
	(6, 1, 2, 'Morning, ', '2021-07-14 16:12:52', 1, '427441'),
	(7, 1, 2, '', '2021-07-14 16:13:09', 1, '468558'),
	(8, 1, 2, 'Afternoon, ', '2021-07-14 16:14:40', 1, '468558'),
	(9, 1, 2, 'Morning, ', '2021-07-14 16:15:38', 1, '158523'),
	(10, 1, 3, 'Afternoon, Night, ', '2021-07-14 16:16:13', 1, '158523'),
	(11, 1, 4, 'Afternoon, ', '2021-07-14 16:16:25', 1, '158523'),
	(12, 1, 1, 'Morning, ', '2023-02-16 15:37:32', 1, '165276');

-- Dumping structure for table prescription.medicine_master
CREATE TABLE IF NOT EXISTS `medicine_master` (
  `Medicine_id` int NOT NULL AUTO_INCREMENT,
  `Company_id` int NOT NULL,
  `Medcine_name` varchar(100) NOT NULL,
  `Description` text NOT NULL,
  `Medicine_status` tinyint(1) NOT NULL,
  `MCreated_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Medicine_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table prescription.medicine_master: 1 rows
/*!40000 ALTER TABLE `medicine_master` DISABLE KEYS */;
INSERT INTO `medicine_master` (`Medicine_id`, `Company_id`, `Medcine_name`, `Description`, `Medicine_status`, `MCreated_date`) VALUES
	(1, 1, 'fsdf', 'sdgsd', 1, '2021-07-14 14:09:22');
/*!40000 ALTER TABLE `medicine_master` ENABLE KEYS */;

-- Dumping structure for table prescription.prescriptions
CREATE TABLE IF NOT EXISTS `prescriptions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` varchar(50) NOT NULL,
  `doctor_id` varchar(50) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL,
  `price` int DEFAULT NULL,
  `track_no` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table prescription.prescriptions: ~5 rows (approximately)
INSERT INTO `prescriptions` (`id`, `uid`, `doctor_id`, `date`, `status`, `price`, `track_no`) VALUES
	(1, 'UID322676', 'UID189070', '2021-07-14 16:01:01', 1, 34, '138561'),
	(2, 'UID322676', 'UID189070', '2021-07-14 16:02:09', 1, 435, '889500'),
	(3, 'UID322676', 'UID189070', '2021-07-14 16:07:39', 1, 435, '889500'),
	(4, 'UID322676', 'UID189070', '2021-07-14 16:12:52', 1, 21, '427441'),
	(5, 'UID322676', 'UID189070', '2021-07-14 16:16:26', 1, 5000, '158523');

-- Dumping structure for table prescription.state_master
CREATE TABLE IF NOT EXISTS `state_master` (
  `State_id` int NOT NULL AUTO_INCREMENT,
  `State_name` varchar(50) NOT NULL,
  `Status` tinyint(1) NOT NULL,
  `SCreated_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`State_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table prescription.state_master: 1 rows
/*!40000 ALTER TABLE `state_master` DISABLE KEYS */;
INSERT INTO `state_master` (`State_id`, `State_name`, `Status`, `SCreated_date`) VALUES
	(1, 'dgs', 1, '2021-07-14 14:12:48');
/*!40000 ALTER TABLE `state_master` ENABLE KEYS */;

-- Dumping structure for table prescription.user_master
CREATE TABLE IF NOT EXISTS `user_master` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `contact` varchar(12) NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL,
  `unique_id` varchar(15) NOT NULL,
  `image` varchar(100) NOT NULL,
  `blood_pressure` varchar(50) DEFAULT NULL,
  `pulse` varchar(50) DEFAULT NULL,
  `blood_group` varchar(50) DEFAULT NULL,
  `height` float DEFAULT NULL,
  `weight` float DEFAULT NULL,
  `city_id` int DEFAULT NULL,
  `state_id` int DEFAULT NULL,
  `district_id` int DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table prescription.user_master: ~2 rows (approximately)
INSERT INTO `user_master` (`user_id`, `first_name`, `last_name`, `gender`, `email`, `contact`, `date_of_birth`, `created_date`, `status`, `unique_id`, `image`, `blood_pressure`, `pulse`, `blood_group`, `height`, `weight`, `city_id`, `state_id`, `district_id`) VALUES
	(1, 'Surajkff', 'Acharf', 'Female', 'suraj@gmail.comdf', '8904652352', '2003-05-07', '2021-07-14 12:50:43', 1, 'UID322676', 'user/profile.jpg', '2', '2', 'B-', 2, 2, 1, 1, 1),
	(2, 'Ajay', 'bt', 'Male', 'ajay@gmail.comd', '8904652353', '2003-05-12', '2021-07-14 12:51:59', 1, 'UID956223', 'user/user_image.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
